package com.bean;
public class StudentBean {

    private int Student_ID ;
    private int Student_DomitoryID ;
    private String Student_Username ;
    private String Student_Password ;
    private String Student_Name ;
    private String Student_Sex ;
    private String Student_Class ;
    private String Student_State ;
	public int getStudent_ID() {
		return Student_ID;
	}
	public void setStudent_ID(int studentID) {
		Student_ID = studentID;
	}
	public int getStudent_DomitoryID() {
		return Student_DomitoryID;
	}
	public void setStudent_DomitoryID(int studentDomitoryID) {
		Student_DomitoryID = studentDomitoryID;
	}
	public String getStudent_Username() {
		return Student_Username;
	}
	public void setStudent_Username(String studentUsername) {
		Student_Username = studentUsername;
	}
	public String getStudent_Password() {
		return Student_Password;
	}
	public void setStudent_Password(String studentPassword) {
		Student_Password = studentPassword;
	}
	public String getStudent_Name() {
		return Student_Name;
	}
	public void setStudent_Name(String studentName) {
		Student_Name = studentName;
	}
	public String getStudent_Sex() {
		return Student_Sex;
	}
	public void setStudent_Sex(String studentSex) {
		Student_Sex = studentSex;
	}
	public String getStudent_Class() {
		return Student_Class;
	}
	public void setStudent_Class(String studentClass) {
		Student_Class = studentClass;
	}
	public String getStudent_State() {
		return Student_State;
	}
	public void setStudent_State(String studentState) {
		Student_State = studentState;
	}
	private String Domitory_Name ;
	private String Building_Name ;
	public String getDomitory_Name() {
		return Domitory_Name;
	}
	public void setDomitory_Name(String domitoryName) {
		Domitory_Name = domitoryName;
	}
	public String getBuilding_Name() {
		return Building_Name;
	}
	public void setBuilding_Name(String buildingName) {
		Building_Name = buildingName;
	}
	private String Domitory_Type ;
    private String Domitory_Number ;
    private String Domitory_Tel ;
	public String getDomitory_Type() {
		return Domitory_Type;
	}
	public void setDomitory_Type(String domitoryType) {
		Domitory_Type = domitoryType;
	}
	public String getDomitory_Number() {
		return Domitory_Number;
	}
	public void setDomitory_Number(String domitoryNumber) {
		Domitory_Number = domitoryNumber;
	}
	public String getDomitory_Tel() {
		return Domitory_Tel;
	}
	public void setDomitory_Tel(String domitoryTel) {
		Domitory_Tel = domitoryTel;
	}
	
}
