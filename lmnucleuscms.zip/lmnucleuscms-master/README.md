About LMNucleus CMS
-------------------

[LMNucleus CMS] (http://nucleus.slightlysome.net/) is a fork of [Nucleus CMS] (http://www.nucleuscms.org/).
The reason for this fork is that currently is the Nucleus CMS project abandoned by its developers 
and the latest version of Nucleus CMS has serious bugs that makes it unusable on newer versions of PHP.
 
[LMNucleus CMS] (http://nucleus.slightlysome.net/) is 100% compatible with [Nucleus CMS] (http://www.nucleuscms.org/) 
and fixes all known bugs in version 3.65 of Nucleus CMS.
