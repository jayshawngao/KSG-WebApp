<?php
// RSD file (http://archipelago.phrasewise.com/rsd)
$CONF = array();
include('./config.php');
selectSkin('xml/rsd');
selector();

?>