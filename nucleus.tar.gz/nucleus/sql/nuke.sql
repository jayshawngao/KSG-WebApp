# MySQL dump 7.1
#
# Host: localhost    Database: nuke
#--------------------------------------------------------
# Server version	3.22.32

#
# Table structure for table 'adminblock'
#
CREATE TABLE adminblock (
  title varchar(60),
  content text
);

#
# Dumping data for table 'adminblock'
#

INSERT INTO adminblock VALUES ('Administration','Admins can have its own box, but just one. Who need more?<br>\r\nAdd the options you like. This box will appear only if you\r\nhas been logged like Admin. No others users can view this.<br>\r\n<li><a href=admin.php3>Administration</a>\r\n<li><a href=admin.php3?op=logout>Logout</a>');

#
# Table structure for table 'authors'
#
CREATE TABLE authors (
  aid varchar(30) DEFAULT '' NOT NULL,
  name varchar(50),
  url varchar(60),
  email varchar(60),
  pwd varchar(13),
  counter int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (aid)
);

#
# Dumping data for table 'authors'
#

INSERT INTO authors VALUES ('God','God','http://www.ncc.org.ve/php-nuke.php3','http://www.ncc.org.ve/php-nuke.php3','Password',1);

#
# Table structure for table 'banner'
#
CREATE TABLE banner (
  bid int(11) DEFAULT '0' NOT NULL auto_increment,
  cid int(11) DEFAULT '0' NOT NULL,
  imptotal int(11) DEFAULT '0' NOT NULL,
  impmade int(11) DEFAULT '0' NOT NULL,
  clicks int(11) DEFAULT '0' NOT NULL,
  imageurl varchar(100) DEFAULT '' NOT NULL,
  clickurl varchar(200) DEFAULT '' NOT NULL,
  date datetime,
  PRIMARY KEY (bid)
);

#
# Dumping data for table 'banner'
#


#
# Table structure for table 'bannerclient'
#
CREATE TABLE bannerclient (
  cid int(11) DEFAULT '0' NOT NULL auto_increment,
  name varchar(60) DEFAULT '' NOT NULL,
  contact varchar(60) DEFAULT '' NOT NULL,
  email varchar(60) DEFAULT '' NOT NULL,
  login varchar(10) DEFAULT '' NOT NULL,
  passwd varchar(10) DEFAULT '' NOT NULL,
  extrainfo text NOT NULL,
  PRIMARY KEY (cid)
);

#
# Dumping data for table 'bannerclient'
#


#
# Table structure for table 'bannerfinish'
#
CREATE TABLE bannerfinish (
  bid int(11) DEFAULT '0' NOT NULL auto_increment,
  cid int(11) DEFAULT '0' NOT NULL,
  impressions int(11) DEFAULT '0' NOT NULL,
  clicks int(11) DEFAULT '0' NOT NULL,
  datestart datetime,
  dateend datetime,
  PRIMARY KEY (bid)
);

#
# Dumping data for table 'bannerfinish'
#


#
# Table structure for table 'comments'
#
CREATE TABLE comments (
  tid int(11) DEFAULT '0' NOT NULL auto_increment,
  pid int(11) DEFAULT '0',
  sid int(11) DEFAULT '0',
  date datetime,
  name varchar(60) DEFAULT '' NOT NULL,
  email varchar(60),
  url varchar(60),
  host_name varchar(60),
  subject varchar(60) DEFAULT '' NOT NULL,
  comment text NOT NULL,
  score tinyint(4) DEFAULT '0' NOT NULL,
  reason tinyint(4) DEFAULT '0' NOT NULL,
  PRIMARY KEY (tid)
);

#
# Dumping data for table 'comments'
#

INSERT INTO comments VALUES (1,0,1,'2000-08-20 13:00:00','','','','150.187.58.193','Re: Welcome to PHP-Nuke 2.5','FIRST COMMENT!\r<br>\n\r<br>\nAll my life I wanted to do this ;)',0,0);

#
# Table structure for table 'counter'
#
CREATE TABLE counter (
  type varchar(80) DEFAULT '' NOT NULL,
  var varchar(80) DEFAULT '' NOT NULL,
  count int(10) unsigned DEFAULT '0' NOT NULL
);

#
# Dumping data for table 'counter'
#

INSERT INTO counter VALUES ('browser','WebTV',0);
INSERT INTO counter VALUES ('browser','Lynx',0);
INSERT INTO counter VALUES ('browser','MSIE',0);
INSERT INTO counter VALUES ('browser','Opera',0);
INSERT INTO counter VALUES ('browser','Konqueror',0);
INSERT INTO counter VALUES ('total','hits',2);
INSERT INTO counter VALUES ('browser','Netscape',1);
INSERT INTO counter VALUES ('os','Linux',1);
INSERT INTO counter VALUES ('browser','Bot',0);
INSERT INTO counter VALUES ('browser','Other',1);
INSERT INTO counter VALUES ('os','Windows',0);
INSERT INTO counter VALUES ('os','Mac',0);
INSERT INTO counter VALUES ('os','FreeBSD',0);
INSERT INTO counter VALUES ('os','SunOS',0);
INSERT INTO counter VALUES ('os','IRIX',0);
INSERT INTO counter VALUES ('os','BeOS',0);
INSERT INTO counter VALUES ('os','OS/2',0);
INSERT INTO counter VALUES ('os','AIX',0);
INSERT INTO counter VALUES ('os','Other',1);

#
# Table structure for table 'lblocks'
#
CREATE TABLE lblocks (
  id tinyint(4) DEFAULT '0' NOT NULL auto_increment,
  title varchar(60),
  content text,
  PRIMARY KEY (id)
);

#
# Dumping data for table 'lblocks'
#

INSERT INTO lblocks VALUES (1,'First Left Block','You can add/remove/edit blocks for your site with PHP-Nuke.\r\nAlso you can add HTML commands like <a href=http://www.ncc.org.ve/php-nuke.php3>links</a>, <b>Bold</b> text, images, etc.\r\nJust use you imagination.');
INSERT INTO lblocks VALUES (2,'Special Sections','What about a <a href=sections.php3>Special Sections</a>option in the PHP-Nuke code? A place to publish reviews, special articles, interviews, or whatever, independent of the main news.');

#
# Table structure for table 'links_categories'
#
CREATE TABLE links_categories (
  cid int(11) DEFAULT '0' NOT NULL auto_increment,
  title varchar(50) DEFAULT '' NOT NULL,
  PRIMARY KEY (cid)
);

#
# Dumping data for table 'links_categories'
#


#
# Table structure for table 'links_links'
#
CREATE TABLE links_links (
  lid int(11) DEFAULT '0' NOT NULL auto_increment,
  cid int(11) DEFAULT '0' NOT NULL,
  sid int(11) DEFAULT '0' NOT NULL,
  title varchar(100) DEFAULT '' NOT NULL,
  url varchar(100) DEFAULT '' NOT NULL,
  description text NOT NULL,
  date datetime,
  name varchar(60) DEFAULT '' NOT NULL,
  email varchar(60) DEFAULT '' NOT NULL,
  hits int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (lid)
);

#
# Dumping data for table 'links_links'
#


#
# Table structure for table 'links_newlink'
#
CREATE TABLE links_newlink (
  lid int(11) DEFAULT '0' NOT NULL auto_increment,
  cid int(11) DEFAULT '0' NOT NULL,
  sid int(11) DEFAULT '0' NOT NULL,
  title varchar(100) DEFAULT '' NOT NULL,
  url varchar(100) DEFAULT '' NOT NULL,
  description text NOT NULL,
  name varchar(60) DEFAULT '' NOT NULL,
  email varchar(60) DEFAULT '' NOT NULL,
  PRIMARY KEY (lid)
);

#
# Dumping data for table 'links_newlink'
#


#
# Table structure for table 'links_subcategories'
#
CREATE TABLE links_subcategories (
  sid int(11) DEFAULT '0' NOT NULL auto_increment,
  cid int(11) DEFAULT '0' NOT NULL,
  title varchar(50) DEFAULT '' NOT NULL,
  PRIMARY KEY (sid)
);

#
# Dumping data for table 'links_subcategories'
#


#
# Table structure for table 'mainblock'
#
CREATE TABLE mainblock (
  title varchar(60),
  content text
);

#
# Dumping data for table 'mainblock'
#

INSERT INTO mainblock VALUES ('Main Menu','<li><a href=index.php3>Home</a>\r\n<li><a href=topics.php3>Topics</a>\r\n<li><a href=sections.php3>Sections</a>\r\n<li><a href=links.php3>Web Links</a>\r\n<li><a href=user.php3>Your Account</a>\r\n<li><a href=submit.php3>Submit News</a>\r\n<li><a href=stats.php3>Stats</a>\r\n<li><a href=top.php3>Top 10</a>\r\n<li><a href=faq.php3>FAQ</a>');

#
# Table structure for table 'poll_data'
#
CREATE TABLE poll_data (
  pollID int(11) DEFAULT '0' NOT NULL,
  optionText char(50) DEFAULT '' NOT NULL,
  optionCount int(11) DEFAULT '0' NOT NULL,
  voteID int(11) DEFAULT '0' NOT NULL
);

#
# Dumping data for table 'poll_data'
#

INSERT INTO poll_data VALUES (1,'Ummmm, not bad',0,1);
INSERT INTO poll_data VALUES (1,'Cool',0,2);
INSERT INTO poll_data VALUES (1,'Terrific',0,3);
INSERT INTO poll_data VALUES (1,'The best one!',0,4);
INSERT INTO poll_data VALUES (1,'what the hell is this?',0,5);
INSERT INTO poll_data VALUES (1,'',0,6);
INSERT INTO poll_data VALUES (1,'',0,7);
INSERT INTO poll_data VALUES (1,'',0,8);
INSERT INTO poll_data VALUES (1,'',0,9);
INSERT INTO poll_data VALUES (1,'',0,10);
INSERT INTO poll_data VALUES (1,'',0,11);
INSERT INTO poll_data VALUES (1,'',0,12);

#
# Table structure for table 'poll_desc'
#
CREATE TABLE poll_desc (
  pollID int(11) DEFAULT '0' NOT NULL auto_increment,
  pollTitle char(100) DEFAULT '' NOT NULL,
  timeStamp int(11) DEFAULT '0' NOT NULL,
  voters mediumint(9) DEFAULT '0' NOT NULL,
  PRIMARY KEY (pollID)
);

#
# Dumping data for table 'poll_desc'
#

INSERT INTO poll_desc VALUES (1,'What do you think about PHP-Nuke?',961405160,0);

#
# Table structure for table 'pollcomments'
#
CREATE TABLE pollcomments (
  tid int(11) DEFAULT '0' NOT NULL auto_increment,
  pid int(11) DEFAULT '0',
  pollID int(11) DEFAULT '0',
  date datetime,
  name varchar(60) DEFAULT '' NOT NULL,
  email varchar(60),
  url varchar(60),
  host_name varchar(60),
  subject varchar(60) DEFAULT '' NOT NULL,
  comment text NOT NULL,
  score tinyint(4) DEFAULT '0' NOT NULL,
  reason tinyint(4) DEFAULT '0' NOT NULL,
  PRIMARY KEY (tid)
);

#
# Dumping data for table 'pollcomments'
#

#
# Table structure for table 'queue'
#
CREATE TABLE queue (
  qid smallint(5) unsigned DEFAULT '0' NOT NULL auto_increment,
  uid mediumint(9) DEFAULT '0' NOT NULL,
  uname varchar(40) DEFAULT '' NOT NULL,
  subject varchar(100) DEFAULT '' NOT NULL,
  story text,
  timestamp datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  topic varchar(20) DEFAULT 'Linux' NOT NULL,
  PRIMARY KEY (qid)
);

#
# Dumping data for table 'queue'
#


#
# Table structure for table 'quotes'
#
CREATE TABLE quotes (
  qid int(10) unsigned DEFAULT '0' NOT NULL auto_increment,
  quote text,
  PRIMARY KEY (qid)
);

#
# Dumping data for table 'quotes'
#

INSERT INTO quotes VALUES (1,'Nos morituri te salutamus - CBHS');

#
# Table structure for table 'rblocks'
#
CREATE TABLE rblocks (
  id tinyint(4) DEFAULT '0' NOT NULL auto_increment,
  title varchar(60),
  content text,
  PRIMARY KEY (id)
);

#
# Dumping data for table 'rblocks'
#

INSERT INTO rblocks VALUES (1,'First Right Block','You can add/remove/edit blocks for your site with PHP-Nuke.\r\nAlso you can add HTML commands like <a href=http://www.ncc.org.ve/php-nuke.php3>links</a>, <b>Bold</b> text, images, etc.\r\nJust use you imagination.');
INSERT INTO rblocks VALUES (2,'Information','<center>\r\nSite made with:<br>\r\n<a href=http://www.ncc.org.ve/php-nuke.php3><img src=images/powered/phpnuke.gif border=0></a><br>\r\n');

#
# Table structure for table 'referer'
#
CREATE TABLE referer (
  rid int(11) DEFAULT '0' NOT NULL auto_increment,
  url varchar(100) DEFAULT '' NOT NULL,
  PRIMARY KEY (rid)
);

#
# Dumping data for table 'referer'
#


#
# Table structure for table 'seccont'
#
CREATE TABLE seccont (
  artid int(11) DEFAULT '0' NOT NULL auto_increment,
  secid int(11) DEFAULT '0' NOT NULL,
  title text NOT NULL,
  content text NOT NULL,
  counter int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (artid)
);

#
# Dumping data for table 'seccont'
#


#
# Table structure for table 'sections'
#
CREATE TABLE sections (
  secid int(11) DEFAULT '0' NOT NULL auto_increment,
  secname varchar(40) DEFAULT '' NOT NULL,
  image varchar(50) DEFAULT '' NOT NULL,
  PRIMARY KEY (secid)
);

#
# Dumping data for table 'sections'
#


#
# Table structure for table 'stories'
#
CREATE TABLE stories (
  sid int(11) DEFAULT '0' NOT NULL auto_increment,
  aid varchar(30) DEFAULT '' NOT NULL,
  title varchar(80),
  time datetime,
  introtext text,
  fulltext text NOT NULL,
  comments int(11) DEFAULT '0',
  counter mediumint(8) unsigned,
  topic int(2) DEFAULT '1' NOT NULL,
  informant varchar(20) DEFAULT '' NOT NULL,
  notes text NOT NULL,
  hits int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (sid)
);

#
# Dumping data for table 'stories'
#

INSERT INTO stories VALUES (1,'god','Welcome to PHP-Nuke 3.0','2000-08-20 12:00:00','This is the first article in PHP-Nuke. You can delete it. Remember to set/change nickname and/or password for the main admin user. There aren\'t any registered/default user, so maybe you want to set the first one. Pelase read carefully the README file for some details, CREDITS files to see from where comes the things and remember that this is free software under the GPL License (COPYING file for details). Hope you enjoy this software. Please report any bug you find, and you\'ll for sure, so drop me an email when one of this annoying things happens and I\'ll try to fix it for the next releases.','',1,2,10,'god','',0);

#
# Table structure for table 'topics'
#
CREATE TABLE topics (
  topicid int(2) DEFAULT '0' NOT NULL auto_increment,
  topicname varchar(20),
  topicimage varchar(20),
  topictext varchar(40),
  counter int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (topicid)
);

#
# Dumping data for table 'topics'
#

INSERT INTO topics VALUES (1,'linux','linux.gif','Linux',0);
INSERT INTO topics VALUES (2,'amd','amd.gif','AMD',0);
INSERT INTO topics VALUES (3,'aol','aol.jpg','America Online',0);
INSERT INTO topics VALUES (4,'caldera','caldera.gif','Caldera Systems',0);
INSERT INTO topics VALUES (5,'apple','mac.gif','Apple / Mac',0);
INSERT INTO topics VALUES (6,'beos','beos.gif','BeOS',0);
INSERT INTO topics VALUES (7,'compaq','compaq.gif','Compaq',0);
INSERT INTO topics VALUES (8,'corel','corel.gif','Corel',0);
INSERT INTO topics VALUES (9,'debian','debian.gif','Debian',0);
INSERT INTO topics VALUES (10,'phpnuke','phpnuke.gif','PHP-Nuke',0);
INSERT INTO topics VALUES (11,'freebsd','freebsd.gif','FreeBSD',0);
INSERT INTO topics VALUES (12,'gimp','gimp.gif','GIMP',0);
INSERT INTO topics VALUES (13,'gnome','gnome.gif','GNOME',0);
INSERT INTO topics VALUES (14,'gnu','gnu.jpg','GNU / GPL',0);
INSERT INTO topics VALUES (15,'hp','hp.gif','Hewlett Packard',0);
INSERT INTO topics VALUES (16,'ibm','ibm.gif','IBM',0);
INSERT INTO topics VALUES (17,'intel','intel.gif','Intel',0);
INSERT INTO topics VALUES (18,'java','java.gif','Java',0);
INSERT INTO topics VALUES (19,'kde','kde.gif','KDE',0);
INSERT INTO topics VALUES (20,'mandrake','mandrake.gif','Mandrake',0);
INSERT INTO topics VALUES (21,'microsoft','microsoft.gif','Microsoft',0);
INSERT INTO topics VALUES (22,'mozilla','mozilla.gif','Mozilla',0);
INSERT INTO topics VALUES (23,'netscape','netscape.gif','Netscape',0);
INSERT INTO topics VALUES (24,'perl','perl.gif','Perl',0);
INSERT INTO topics VALUES (25,'redhat','redhat.gif','Red Hat',0);
INSERT INTO topics VALUES (26,'sgi','sgi.gif','Silicon Graphics',0);
INSERT INTO topics VALUES (27,'sun','sun.gif','Sun Microsystems',0);
INSERT INTO topics VALUES (28,'suse','suse.gif','SuSE',0);
INSERT INTO topics VALUES (29,'x','x.jpg','X Window',0);

#
# Table structure for table 'users'
#
CREATE TABLE users (
  uid int(11) DEFAULT '0' NOT NULL auto_increment,
  name varchar(60) DEFAULT '' NOT NULL,
  uname varchar(25) DEFAULT '' NOT NULL,
  email varchar(60) DEFAULT '' NOT NULL,
  femail varchar(60) DEFAULT '' NOT NULL,
  url varchar(100) DEFAULT '' NOT NULL,
  pass varchar(20) DEFAULT '' NOT NULL,
  storynum tinyint(4) DEFAULT '10' NOT NULL,
  umode varchar(10) DEFAULT '' NOT NULL,
  uorder tinyint(1) DEFAULT '0' NOT NULL,
  thold tinyint(1) DEFAULT '0' NOT NULL,
  noscore tinyint(1) DEFAULT '0' NOT NULL,
  bio tinytext NOT NULL,
  ublockon tinyint(1) DEFAULT '0' NOT NULL,
  ublock tinytext NOT NULL,
  theme varchar(255) DEFAULT '' NOT NULL,
  commentmax int(11) DEFAULT '4096' NOT NULL,
  counter int(11) DEFAULT '0' NOT NULL,
  PRIMARY KEY (uid)
);

#
# Dumping data for table 'users'
#


