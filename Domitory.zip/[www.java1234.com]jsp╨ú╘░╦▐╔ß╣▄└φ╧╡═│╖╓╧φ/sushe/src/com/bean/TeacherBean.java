package com.bean;
public class TeacherBean {

    private int Teacher_ID ;
    private String Teacher_Username ;
    private String Teacher_Password ;
    private String Teacher_Name ;
    private String Teacher_Sex ;
    private String Teacher_Tel ;
	public int getTeacher_ID() {
		return Teacher_ID;
	}
	public void setTeacher_ID(int teacherID) {
		Teacher_ID = teacherID;
	}
	public String getTeacher_Username() {
		return Teacher_Username;
	}
	public void setTeacher_Username(String teacherUsername) {
		Teacher_Username = teacherUsername;
	}
	public String getTeacher_Password() {
		return Teacher_Password;
	}
	public void setTeacher_Password(String teacherPassword) {
		Teacher_Password = teacherPassword;
	}
	public String getTeacher_Name() {
		return Teacher_Name;
	}
	public void setTeacher_Name(String teacherName) {
		Teacher_Name = teacherName;
	}
	public String getTeacher_Sex() {
		return Teacher_Sex;
	}
	public void setTeacher_Sex(String teacherSex) {
		Teacher_Sex = teacherSex;
	}
	public String getTeacher_Tel() {
		return Teacher_Tel;
	}
	public void setTeacher_Tel(String teacherTel) {
		Teacher_Tel = teacherTel;
	}
    
	
}
