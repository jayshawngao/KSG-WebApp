<?php
	define('_PING_DESC', 'This plugin can be used to ping many blog tracking services. - Don\'t forget to enable the option \'Ping weblog listing service on update\' in your blog settings!');
	define('_PING_PINGOM', 'Ping-o-matic');
	define('_PING_WEBLOGS', 'weblogs.com');
	define('_PING_TECHNOR', 'Technorati');
	define('_PING_BLOGR', 'Blogrolling');
	define('_PING_BLOGS', 'Blo.gs (no longer works?)');
	define('_PING_WEBLOGUES', 'Weblogues (no longer works?)');
	define('_PING_BLOGGDE', 'Blogg.de (not working??)');
	define('_PING_BG', 'Ping from background when a future post first appears');
	define('_PINGING', 'Pinging ');
	define('_PING_ERROR', 'Error');
	define('_PING_PHP_ERROR', 'PHP Error: ');
	define('_PING_PHP_PING_ERROR', 'Error while trying to send ping. Sorry about that.');
	define('_PING_SUCCESS', 'Success');
	define('_UPDATEDPING_GOSENDPING', 'Send Update ping'); 
	define('_PING_EXTRA_PLUGIN_OPTION', 'Blog Tracking Ping Service');
	define('_PING_SENDPING', 'Notify ping service when new post is added?');
?>
